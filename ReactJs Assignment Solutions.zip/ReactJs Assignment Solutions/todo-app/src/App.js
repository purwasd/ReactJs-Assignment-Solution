import logo from './logo.svg';
import './App.css';
import AddTodo from './addTodo';

function App() {
  return (
    <div className="App">
     <AddTodo></AddTodo>
    </div>
  );
}

export default App;
