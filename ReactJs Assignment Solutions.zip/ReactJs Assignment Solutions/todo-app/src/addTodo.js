
import React, {Component} from 'react'
import { Col, FormControl, InputGroup, ListGroup, Row } from 'react-bootstrap'

import Container from 'react-bootstrap/Container'



class AddTodo extends Component{

    constructor(props){
        super(props);
        this.state = {
            userInput : "",
            listItems : []
        }
    }

    updateUserInput(value){
        this.setState({
            userInput : value,
        })
    }
    
    addItem(){
        const input = this.state.userInput;
        if(input !== ''){
            const userInput = {
                id: Math.random(),
                value: input
            };


        const list = this.state.listItems;
        const listItems = [...list];
        listItems.push(userInput);

        this.setState({
            listItems,
            userInput: ""
        })
        }
    }

   
    render(){
        const input = this.state.userInput, list = this.state.listItems;
        return(
            <Container>
                <Row className = "rowTitle">
                   <h1>TODO LIST</h1> 
                </Row>

               
                <div>
                <InputGroup className = "input">
                <FormControl className="textb" placeholder = "Add Item" size="lg" value = {input}
                onChange = {item => this.updateUserInput(item.target.value)}
                aria-label = "Add Something"
                 ></FormControl>

                 <InputGroup.Append>
                    <button className="btn"  onClick={() =>this.addItem() }>Add Items</button>
                 </InputGroup.Append>
                </InputGroup>
               
                </div>
                <div>
                       <ListGroup className="lists">
                        {list.map(item => {return(
                            <ListGroup.Item>
                            {item.value}
                            </ListGroup.Item>
                        )}

                        )}
                       </ListGroup>
                       </div>
            </Container>
           
        )
    }
}
export default AddTodo